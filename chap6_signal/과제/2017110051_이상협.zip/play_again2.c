/*
file        : play_again2.c
author      : 2017110051_이상협
datetime    : 2021-10-08 10:50
description : code that allows user to return if user answer
              according to the criteria without showing the output through extension of play_again1.c file
*/

#include <stdio.h>
#include <termios.h>

#define QUESTION "Do you want another transaction"

int get_response(char *);
void set_cr_noecho_mode(void); // add noecho mode
void tty_mode(int);

int main(void) {

    int response;

    tty_mode(0);
    set_cr_noecho_mode();              // set -icanon, -echo
    response = get_response(QUESTION);
    tty_mode(1);

    return response;
}

int get_response(char* question) {
    
    printf("%s (y/n)?", question);

    while(1) {
            switch( getchar() ) {
                case 'y':
                case 'Y': return 0;
                case 'n':
                case 'N':
                case EOF: return 1; // don`t output error report
            }
    }
}

void set_cr_noecho_mode(void) {

    struct termios ttystate;

    tcgetattr(0, &ttystate);
    ttystate.c_lflag &= ~ICANON;
    ttystate.c_lflag &= ~ECHO;          // no echo setting
    ttystate.c_cc[VMIN] = 1;
    tcsetattr(0, TCSANOW, &ttystate);
}

void tty_mode(int how) {

    static struct termios original_mode;
    if ( how == 0 ) {
        tcgetattr(0, &original_mode);
    }
    else {
        tcsetattr(0, TCSANOW, &original_mode);
    }
}
